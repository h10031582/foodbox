export class User {

    id:Number | undefined;
	  username:string | undefined;
	 password:string | undefined;
	  rollid:Number | undefined;
}
