import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Categeory } from '../categeory';
import { CategeoryService } from '../categeory.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  categeory:Categeory[] | undefined;
  constructor(private categeoryService:CategeoryService,
    private router:Router) { }

  ngOnInit(): void {
    this.getCategeories();
  }
  getCategeories() {
    this.categeoryService.getCategeoryList().subscribe(data=>{
      this.categeory=data;
       
      console.log(this.categeory);  
    })
  }
  foodItemMethod(catid:number)
  {
    this.router.navigate(['fooditemlist',catid]);
  }
}
