import { Component, OnInit } from '@angular/core';
import { Fooditem } from '../fooditem';
import { FooditemService } from '../fooditem.service';

@Component({
  selector: 'app-addfooditem',
  templateUrl: './addfooditem.component.html',
  styleUrls: ['./addfooditem.component.css']
})
export class AddfooditemComponent implements OnInit {
  fooditem:Fooditem=new Fooditem();
  constructor(private fooditemService:FooditemService) { }

  ngOnInit(): void {
  }
  onSubmit()
  {
    this.fooditemService.createNewCategeory(this.fooditem).subscribe(data=>{
      console.log(data);
 
  alert("Inserted Foditem  Data Successfully   "+"Food Categeory : "+this.fooditem.fcatid +
  "Foodname : "+this.fooditem.fname+
  "Foodimglink : "+this.fooditem.fimglink);
 
     }
   ,
  error => console.log(error));
  }
}
