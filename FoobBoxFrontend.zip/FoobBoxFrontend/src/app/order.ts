export class Order {
    oid:number;
    fid:number;
    fcatid:number;
    fname:string ;
    price:number;
    qty:number;
    totalamount:number;

    fimglink:string;
}
