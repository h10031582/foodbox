import { Tt } from './tt';

describe('Tt', () => {
  it('should create an instance', () => {
    expect(new Tt()).toBeTruthy();
  });
});
