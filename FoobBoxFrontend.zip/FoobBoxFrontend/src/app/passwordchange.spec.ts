import { Passwordchange } from './passwordchange';

describe('Passwordchange', () => {
  it('should create an instance', () => {
    expect(new Passwordchange()).toBeTruthy();
  });
});
