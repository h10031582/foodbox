import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from './register';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  
  private baseurl="http://localhost:8080/api/v1/register";
  constructor(private httpClient:HttpClient) { }
  registerUser(register:Register):Observable<object>{
    return this.httpClient.post(`${this.baseurl}`,register);
    
  }
}
