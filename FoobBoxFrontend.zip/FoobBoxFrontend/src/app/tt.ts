export class Tt {

    id:number=0;
    name:string='';
}
