import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
 
import { Fooditem } from '../fooditem';
import { FooditemService } from '../fooditem.service';
import { Order } from '../order';
import { OrderService } from '../order.service';
import { Tt } from '../tt';

@Component({
  selector: 'app-fooditemslist',
  templateUrl: './fooditemslist.component.html',
  styleUrls: ['./fooditemslist.component.css']
})
export class FooditemslistComponent implements OnInit {
  fcatid:number;
  qty:number ;
  isShowCart: boolean=false;
  fooditemlist:Fooditem[] =[];
  selectedFooditem: Fooditem ;
  orderArray:Order[]=[];
  orderArray2:Order[]=[];
   orderobj:Order=new Order();
   totalAmount:number;
  
  constructor(private fooditemService:FooditemService,private orderService:OrderService,
    private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {

    this.fcatid=this.route.snapshot.params['fcatid'];
    this.fooditemService.getFoodItemsListwithCatid(this.fcatid).subscribe(data=>{

      this.fooditemlist=data;
    },error=>console.error(error));
  }

  tt:Tt =new Tt();
  ttlist:Tt[] =[];

   
     
  AddtoCart(fid:number,qty:string)
 
  {
    
     
   
    this.fooditemService.getFooditemwihtfid(fid).subscribe(data=>{

      this.selectedFooditem=data;
      
      //this.qty=Number(this.route.snapshot.params['qty']);
      if(Number(qty)!=0)
      {
      if(this.selectedFooditem.fname!=null)
      {
       
        this.orderobj.fid=this.selectedFooditem.fid;
        this.orderobj.fcatid=this.selectedFooditem.fcatid;
        this.orderobj.fname=this.selectedFooditem.fname;
        this.orderobj.price=this.selectedFooditem.price;
        this.orderobj.fimglink=this.selectedFooditem.fimglink;
        this.orderobj.qty=Number(qty);
        this.orderobj.totalamount=(this.orderobj.qty*this.orderobj.price);
        this.totalAmount=this.orderobj.totalamount;
        // alert(this.orderobj.fid+"     "+
        //   this.orderobj.fcatid+"     "+
        //   this.orderobj.fname+"     "+
        //   this.orderobj.price+"     "+
        //   this.orderobj.fimglink+"     "+
        //   this.orderobj.qty+"     "+
        //   this.orderobj.totalamount+"     ");

        this.orderArray.push(this.orderobj); debugger
         
          this.tt.id=this.orderobj.qty;
          this.tt.name=this.orderobj.fname;
          this.ttlist.push(this.tt);
          
          this.orderArray.forEach(function (value) {
            console.log("ID : "+value.fid+" name : "+value.fname);
            alert("ID : "+value.fid+" name : "+value.fname);
          }); 
       if(this.totalAmount!=0)
        
       this.isShowCart = true;  
       else{
         this.isShowCart = false;
       }
      
       
         
      }
    }
    else
    alert("Please add quantity");
      
    },error=>console.error(error));
 
    
    
  }

  
  
  placeOrderClick()
  {
    for (var val of this.orderArray) {
      this.orderService.insertOrder(val).subscribe(data=>{
        console.log(data);
       
    
       }
     ,
    error => console.log(error));
    }
  this.router.navigate(["/paymentdone"]);
  
//    this.orderService.insertOrder(this.orderobj).subscribe(data=>{
//     console.log(data);
//     this.router.navigate(["/paymentdone"]);

//    }
//  ,
// error => console.log(error));

 
  
}

private _listFilter = '';
  get listFilter(): string {
    return this._listFilter;
  }
  set listFilter(value: string) {
    this._listFilter = value;
    this.fooditemlist = this.performFilter(value);
  }


  performFilter(filterBy: string): Fooditem[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.fooditemlist.filter((fooditem: Fooditem) =>
    fooditem.fname.toLocaleLowerCase().includes(filterBy));
  }

}