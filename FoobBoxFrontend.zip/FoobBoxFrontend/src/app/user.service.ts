import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from './register';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  private baseurl="http://localhost:8080/api/v1/login";
  private baseurlforChangePassword="http://localhost:8080/api/v1/changepassword";
  constructor(private httpClient:HttpClient) { }

  userLoginCheck(username:string,password:string,rollid:number):Observable<Register>
  {
return this.httpClient.get<Register>(`${this.baseurl}/${username}/${password}/${rollid}`);
  }

  
  passwordChange(currentpassword:string,newpassword:string):Observable<Number>
  {
return this.httpClient.get<Number>(`${this.baseurlforChangePassword}/${currentpassword}/${newpassword}`);
  }
}

