import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentdonepage',
  templateUrl: './paymentdonepage.component.html',
  styleUrls: ['./paymentdonepage.component.css']
})
export class PaymentdonepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
