import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentdonepageComponent } from './paymentdonepage.component';

describe('PaymentdonepageComponent', () => {
  let component: PaymentdonepageComponent;
  let fixture: ComponentFixture<PaymentdonepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentdonepageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentdonepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
