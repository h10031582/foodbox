export class Categeory {
      catid :number=0;
      catName:string | undefined ;
      catimglink:string | undefined ;

}
