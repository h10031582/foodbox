import { Categeory } from './categeory';

describe('Categeory', () => {
  it('should create an instance', () => {
    expect(new Categeory()).toBeTruthy();
  });
});
