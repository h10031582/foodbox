import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HomeheaderComponent } from './homeheader/homeheader.component';
import { FooterComponent } from './footer/footer.component';
import { AdminformComponent } from './adminform/adminform.component';
import { AdminheaderComponent } from './adminheader/adminheader.component';
import { AddcategeoryComponent } from './addcategeory/addcategeory.component';
 
 
import { AddfooditemComponent } from './addfooditem/addfooditem.component';
 
import { PasswordchangeComponent } from './passwordchange/passwordchange.component';
import { FooditemslistComponent } from './fooditemslist/fooditemslist.component';
import { EditcategeoryComponent } from './editcategeory/editcategeory.component';
import { EditfooditemComponent } from './editfooditem/editfooditem.component';
import { UpdatecategeoryComponent } from './updatecategeory/updatecategeory.component';
import { UpdatefooditemComponent } from './updatefooditem/updatefooditem.component';
import { PaymentdonepageComponent } from './paymentdonepage/paymentdonepage.component';
@NgModule({
  declarations: [
    AppComponent,
    RegisterFormComponent,
    LoginComponent,
    HomeComponent,
    HomeheaderComponent,
    FooterComponent,
    AdminformComponent,
    AdminheaderComponent,
    AddcategeoryComponent,
     
   
    AddfooditemComponent,
    
    PasswordchangeComponent,
         FooditemslistComponent,
         EditcategeoryComponent,
         EditfooditemComponent,
         UpdatecategeoryComponent,
         UpdatefooditemComponent,
         PaymentdonepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
