import { Fooditem } from './fooditem';

describe('Fooditem', () => {
  it('should create an instance', () => {
    expect(new Fooditem()).toBeTruthy();
  });
});
