import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Categeory } from './categeory';

@Injectable({
  providedIn: 'root'
})
export class CategeoryService {

  private baseurl="http://localhost:8080/api/v1/categeory";
  private baseurlForGetCategeories="http://localhost:8080/api/v1/getcategeory";
  private baseurlForGetCategeoryWithCathId="http://localhost:8080/api/v1/categeoryitem";
  private baseurlForUpdateCategeoryWithCathId="http://localhost:8080/api/v1/updatecategeory";
  constructor(private httpClient:HttpClient) { }
  createNewCategeory(categeory:Categeory):Observable<object>{
     
    return this.httpClient.post(`${this.baseurl}`,categeory);
     
  }

  getCategeoryList():Observable<Categeory[]>
  {
return this.httpClient.get<Categeory[]>(`${this.baseurlForGetCategeories}`);
  }

  getCategeorywihtCatid(catid:Number):Observable<Categeory>
  {
return this.httpClient.get<Categeory>(`${this.baseurlForGetCategeoryWithCathId}/${catid}`);
  }

  updateCategeoryByCatIdService(catid:Number,categeory:Categeory):Observable<object>{
    return this.httpClient.put(`${this.baseurlForUpdateCategeoryWithCathId}/${catid}`,categeory);
  }
}
