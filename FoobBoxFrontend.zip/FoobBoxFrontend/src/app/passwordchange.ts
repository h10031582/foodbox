export class Passwordchange {
    currentpassword:string ="";
	 newpassword:string ="";
     confirmpassword:string="";

}
