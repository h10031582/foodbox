import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecategeoryComponent } from './updatecategeory.component';

describe('UpdatecategeoryComponent', () => {
  let component: UpdatecategeoryComponent;
  let fixture: ComponentFixture<UpdatecategeoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatecategeoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatecategeoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
