import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Categeory } from '../categeory';
import { CategeoryService } from '../categeory.service';

@Component({
  selector: 'app-updatecategeory',
  templateUrl: './updatecategeory.component.html',
  styleUrls: ['./updatecategeory.component.css']
})
export class UpdatecategeoryComponent implements OnInit {
  catid:number =0;
  categeory:Categeory=new Categeory();
  constructor(private categeoryService:CategeoryService,
    private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.catid=this.route.snapshot.params['catid'];
    this.categeoryService.getCategeorywihtCatid(this.catid).subscribe(data=>{

      this.categeory=data;
      
    },error=>console.error(error));

    
    
  }

  onSubmit()
  {
    this.categeoryService.updateCategeoryByCatIdService(this.catid,this.categeory).subscribe(data=>{
      this.gotoCatageory();
    },error=> console.error());
  }
  gotoCatageory() {
    alert("Updated...")
    this.router.navigate(["/editcat"]);
  }

}
