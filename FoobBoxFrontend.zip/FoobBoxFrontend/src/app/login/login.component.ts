import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../register';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
 register:Register=new Register();
 roll:string | undefined;
  constructor(private userservice:UserService,
    private router:Router) { }

  ngOnInit(): void {
    
  }
  onSubmit()
  {
    this.router.navigate(["/admin"]);
  }
  // onSubmit()
  // {
  //   this.userservice.userLoginCheck(this.register.firstName,this.register.password,this.register.rollid).subscribe(data=>{
  //     this.register=data;
  //      if(this.register!=null)
  //      {
  //      if(this.register.rollid==1)
  //      {
  //       alert("Successfully Admin Credentials")
  //       this.router.navigate(["/admin"]);
  //      }  
  //      else if(this.register.rollid==2)
  //      {
  //       alert("Successfully Normal User Credentials")
  //      }
  //      else
  //      {
  //        alert("Invalid Credentials")
  //      }
  //     }
  //     else
  //     alert("No data came.Invalid Credentials")
  //   })


  //   // if(this.register. rollid==1)
  //   // this.roll='Admin';
  //   // if(this.register. rollid==2)
  //   // this.roll='Normal User';
  //   // alert("Login Successfully   "+"User Name : "+this.register.firstName+
  //   // "Password : "+this.register. password+
  //   // " Roll : "+this.roll );
     
  // }

  
}
