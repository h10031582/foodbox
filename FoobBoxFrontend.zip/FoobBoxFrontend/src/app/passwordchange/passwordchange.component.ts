import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Passwordchange } from '../passwordchange';
import { UserService } from '../user.service';

@Component({
  selector: 'app-passwordchange',
  templateUrl: './passwordchange.component.html',
  styleUrls: ['./passwordchange.component.css']
})
export class PasswordchangeComponent implements OnInit {
  currentpassword:string | undefined;
  newpassword:string| undefined;
  count:Number| undefined;
  passwordchange:Passwordchange=new Passwordchange();
  constructor(private userservice:UserService,
    private router:Router) { }

  ngOnInit(): void {
  }

  onSubmit()
  {
      
    
    this.userservice.passwordChange(this.passwordchange.currentpassword,this.passwordchange.newpassword).subscribe((data) => {
      this.count=data
      if(this.count>0)
  {
    alert("Password Changed");
    this.router.navigate(['signin']);
  }
  else{
    alert("Password Not Changed");
  }
  });
   
  
  }

}
