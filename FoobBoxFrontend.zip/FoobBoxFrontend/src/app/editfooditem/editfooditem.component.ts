import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fooditem } from '../fooditem';
import { FooditemService } from '../fooditem.service';

@Component({
  selector: 'app-editfooditem',
  templateUrl: './editfooditem.component.html',
  styleUrls: ['./editfooditem.component.css']
})
export class EditfooditemComponent implements OnInit {
  fooditems:Fooditem[] | undefined
  constructor(private fooditemService:FooditemService,
    private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.getAllFooditemList();
  }
  getAllFooditemList() {
    this.fooditemService.getAllFoodItemsList().subscribe(data=>{
      this.fooditems=data;
         },error=>console.error(error));
  }
  updateCategeory(fid:Number)
  {
    this.router.navigate(['updatefooditem',fid]);
  }
  deleteCategeory(fid:Number)  
  {

  }
}
