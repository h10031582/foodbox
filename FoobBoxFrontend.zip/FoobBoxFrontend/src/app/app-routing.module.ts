import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddcategeoryComponent } from './addcategeory/addcategeory.component';
import { AddfooditemComponent } from './addfooditem/addfooditem.component';
import { AdminformComponent } from './adminform/adminform.component';
import { EditcategeoryComponent } from './editcategeory/editcategeory.component';
import { EditfooditemComponent } from './editfooditem/editfooditem.component';
import { FooditemslistComponent } from './fooditemslist/fooditemslist.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PasswordchangeComponent } from './passwordchange/passwordchange.component';
import { PaymentdonepageComponent } from './paymentdonepage/paymentdonepage.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { UpdatecategeoryComponent } from './updatecategeory/updatecategeory.component';
import { UpdatefooditemComponent } from './updatefooditem/updatefooditem.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
{path:'register',component:RegisterFormComponent},
{path:'admin',component:AdminformComponent},
{path:'categeory',component:AddcategeoryComponent},
{path:'fooditem',component:AddfooditemComponent},
{path:'changepassword',component:PasswordchangeComponent},
{path:'fooditemlist/:fcatid',component:FooditemslistComponent},
{path:'editcat',component:EditcategeoryComponent},
{path:'edititem',component:EditfooditemComponent},
{path:'updatecat/:catid',component:UpdatecategeoryComponent},
{path:'updatefooditem/:fid',component:UpdatefooditemComponent},
{path:'paymentdone',component:PaymentdonepageComponent}




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
