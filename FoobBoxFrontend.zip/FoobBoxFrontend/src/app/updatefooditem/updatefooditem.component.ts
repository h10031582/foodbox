import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fooditem } from '../fooditem';
import { FooditemService } from '../fooditem.service';

@Component({
  selector: 'app-updatefooditem',
  templateUrl: './updatefooditem.component.html',
  styleUrls: ['./updatefooditem.component.css']
})
export class UpdatefooditemComponent implements OnInit {
  fid:number=0;
  fooditem:Fooditem=new Fooditem();
  constructor(private fooditemService:FooditemService,
    private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    
    

    this.fid=this.route.snapshot.params['fid'];
    this.fooditemService.getFooditemwihtfid(this.fid).subscribe(data=>{

      this.fooditem=data;
      
    },error=>console.error(error));

    
  }

  onSubmit()
  {

    this.fooditemService.updateFooditemByFIdService(this.fid,this.fooditem).subscribe(data=>{
      this.gotoFooditems();
    },error=> console.error());
  }
  gotoFooditems() {
    alert("Updated...")
    this.router.navigate(["/edititem"]);
  }
}
