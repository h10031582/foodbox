import { Component, OnInit } from '@angular/core';
import { Categeory } from '../categeory';
import { CategeoryService } from '../categeory.service';

@Component({
  selector: 'app-addcategeory',
  templateUrl: './addcategeory.component.html',
  styleUrls: ['./addcategeory.component.css']
})
export class AddcategeoryComponent implements OnInit {
  categeory:Categeory=new Categeory();
  constructor(private categeoryService:CategeoryService) { }

  ngOnInit(): void {
  }
  onSubmit()
  {
    this.categeoryService.createNewCategeory(this.categeory).subscribe(data=>{
      console.log(data);
 
  alert("Inserted Categeory  Data Successfully   "+"categeoryname : "+this.categeory.catName+
  "imglink : "+this.categeory.catimglink);
 
     }
   ,
  error => console.log(error));
  }
}
