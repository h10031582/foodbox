import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddcategeoryComponent } from './addcategeory.component';

describe('AddcategeoryComponent', () => {
  let component: AddcategeoryComponent;
  let fixture: ComponentFixture<AddcategeoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddcategeoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddcategeoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
