export class Register {
    id : number | undefined ;
    firstName:string ='';
    lastName:string | undefined;
    password:string ='';
    phno:number | undefined;
    email:string | undefined;
    pincode:number | undefined;
    rollid:number =0;
   

}
