import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditcategeoryComponent } from './editcategeory.component';

describe('EditcategeoryComponent', () => {
  let component: EditcategeoryComponent;
  let fixture: ComponentFixture<EditcategeoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditcategeoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditcategeoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
