import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Categeory } from '../categeory';
import { CategeoryService } from '../categeory.service';

@Component({
  selector: 'app-editcategeory',
  templateUrl: './editcategeory.component.html',
  styleUrls: ['./editcategeory.component.css']
})
export class EditcategeoryComponent implements OnInit {
  categeory:Categeory[] | undefined
  constructor(private categeoryService:CategeoryService,
    private route:ActivatedRoute,private router:Router) { }
    
  ngOnInit(): void {
    this.getAllCategeoryList();
  }
  getAllCategeoryList()
  {
    this.categeoryService.getCategeoryList().subscribe(data=>{
      this.categeory=data;
         },error=>console.error(error));
  }
  updateCategeory(catid:Number)
  {
    this.router.navigate(['updatecat',catid]);
  }
  deleteCategeory(catid:Number)  
  {

  }
}
