import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private baseurlForInsertOrder="http://localhost:8080/api/v1/orderinsert";
  constructor(private httpClient:HttpClient) { }
  
 insertOrder(order:Order):Observable<object>{
     
    return this.httpClient.post(`${this.baseurlForInsertOrder}`,order);
     
  }
}
