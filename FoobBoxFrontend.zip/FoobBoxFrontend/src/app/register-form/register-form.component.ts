import { Component, OnInit } from '@angular/core';
import { Register } from '../register';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {
  register:Register=new Register();
  constructor(private registerService:RegisterService) { }

  ngOnInit(): void {
  }
  onSubmit()
  {
     this.registerService.registerUser(this.register).subscribe(data=>{
      console.log(data);
        
       
    alert("Registered Data Successfully   "+"First Name : "+this.register.firstName+
    "Last Name : "+this.register.lastName+
    " Phone Number : "+this.register.phno+
    "Email : "+this.register.email+
    "Pincode : "+this.register.pincode+
    "RollId : "+this.register.rollid);
  
  
     //this.register.firstName='';
    // this.register.lastName='';
     //this.register.phno=undefined;
     //this.register.email='';
     //this.register.pincode=undefined;
     //this.register.rollid=undefined;
  }
   ,
  error => console.log(error));
 }
}
