
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Fooditem } from './fooditem';

@Injectable({
  providedIn: 'root'
})
export class FooditemService {
 
  private baseurl="http://localhost:8080/api/v1/fooditem";
  private baseurlByCatid="http://localhost:8080/api/v1/foodlistitem";
  private baseurlForAllFooditems="http://localhost:8080/api/v1/allfoodlistitem";
  private baseurlForGetFooditemWithFoodId="http://localhost:8080/api/v1/fooditemwithfid";
   private baseurlForUpdateFooditemWithFoodId="http://localhost:8080/api/v1/updatefooditem";

  constructor(private httpClient:HttpClient) { }
  createNewCategeory(fooditem:Fooditem):Observable<object>{
     
    return this.httpClient.post(`${this.baseurl}`,fooditem);
     
  }

  getFoodItemsListwithCatid(fcatid:Number):Observable<Fooditem[]>
  {
return this.httpClient.get<Fooditem[]>(`${this.baseurlByCatid}/${fcatid}`);
  }

  getAllFoodItemsList():Observable<Fooditem[]>
  {
return this.httpClient.get<Fooditem[]>(`${this.baseurlForAllFooditems}`);
  }
  getFooditemwihtfid(fid:Number):Observable<Fooditem>
  {
return this.httpClient.get<Fooditem>(`${this.baseurlForGetFooditemWithFoodId}/${fid}`);
  }
  updateFooditemByFIdService(fid:Number,fooditem:Fooditem):Observable<object>{
    return this.httpClient.put(`${this.baseurlForUpdateFooditemWithFoodId}/${fid}`,fooditem);
  }
   
}
