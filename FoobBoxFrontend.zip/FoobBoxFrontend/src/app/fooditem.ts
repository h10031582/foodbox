export class Fooditem {

        fid:number
    fcatid:number;
    fname:string ;
    price:number;
    fimglink:string;

    
}
